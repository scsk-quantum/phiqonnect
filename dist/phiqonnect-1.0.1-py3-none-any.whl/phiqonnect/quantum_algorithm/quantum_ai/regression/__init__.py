""" QSVR Package """

from .qsvr import QSVR

__all__ = [
    "QSVR", 
]