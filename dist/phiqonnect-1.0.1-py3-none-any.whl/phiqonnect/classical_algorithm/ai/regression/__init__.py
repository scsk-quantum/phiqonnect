""" SVR Package """

from .classical_svr import ClassicalSVR

__all__ = [
    "ClassicalSVR", 
]