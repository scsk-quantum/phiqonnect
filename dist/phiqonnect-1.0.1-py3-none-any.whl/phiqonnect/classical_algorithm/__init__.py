""" Classical Algorithm Package """

__all__ = [
    "ai"
]